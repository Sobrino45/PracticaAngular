import { Component } from '@angular/core';

@Component({
  selector: 'app-acercade',
  standalone: false,
  templateUrl: './acercade.component.html',
  styleUrls: ['./acercade.component.css']
})
export class AcercadeComponent {}
