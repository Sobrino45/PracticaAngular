import { AbreviarNumeroPipe } from './abreviar-numero.pipe';

describe('AbreviarNumeroPipe', () => {
  it('create an instance', () => {
    const pipe = new AbreviarNumeroPipe();
    expect(pipe).toBeTruthy();
  });
});
